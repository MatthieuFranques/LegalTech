// asignation des differente partie du formulaire 
var divs = ["partie1", "partie2", "partie3", "partie4"];
var visibleId = null;
//fonction pour afficher les checkbox en fonction du boutton radio
function show(id) {
    //si ID et differend de la variable ID alors il prend la valeur de l'id
if(visibleId !== id) {
    visibleId = id;
} 
//execute la fonction hide
hide();
}
function hide() {
//assignation des vairable
var div, i, id;
//pour les valeurs de partie1 A partie4
for(i = 0; i < divs.length; i++) {
    id = divs[i];
    //verification du lien qui a etait utilise
    div = document.getElementById(id);
    if(visibleId === id) {  
        //si l'id et la meme on enlève dispay : none 
    div.style.display = "block";
    //sinon on le laisse
    } else {
    div.style.display = "none";
    }
}
}

function popup(){
    document.getElementById("popup").classList.toggle("active");
}

