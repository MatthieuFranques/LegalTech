<head>

<link rel="stylesheet" href="css.css" type="text/css">
<link rel="shortcut icon"  sizes="16x16" href="images/icon_onglet.png">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<script type="text/javascript" src="javascript.js"></script>
<title>Legal Entreprise</title>
</head>
<?php 
	session_start();
	include("view/v_entete.php");
    require_once("model/ClassPDO.php");
    require_once("model/function.php");


	if(!isset($_REQUEST['uc'])){
		$uc = 'Accueil';
	}
	else{
		$uc = $_REQUEST['uc'];
	}
	$pdo = PDOLegalTech::getPDOLegalTech();
	switch($uc)
	{
		case 'Accueil': {
			include("view/v_accueil.php");break;
		}
		case 'connexion' :
		{
			include("Controler/c_connexion.php");break;
		} 

		case 'service' : {
			include("Controler/c_service.php"); break;
		}
		case 'creationEntreprise' :{
			include("Controler/c_formulaireEntreprise.php");break;
		}
		case 'dashboard' :{
			include("Controler/c_dashboard.php");break;
		}
	}
		
	include("view/v_pied.php");

?>


