<?php
$action = $_REQUEST['action'];
if($action != ""){
    switch($action)
    {
        case  "tarif" : {
            $ligne1=$pdo->tarif();
            $ligne2=$pdo->tarif1();
            include("view/v_tarif.php");
            break;
        }
        
        case  "offre" : {
           
            $libelle="";
            $ligne1="";
           
            include("view/v_offre.php");
            break;
                
        }
        case "rejoidreAvocat" : {

            include("view/v_etesVAvocat.php");
            break;

        }
        case "typeoffre" : {
            $libelle=$_POST['check'];
         
            $ligne1=$pdo->nom($libelle);
            break;
        }
        case "injonction" : {
            include("view/formulaireInjonction/v_injonction.php");
        }
        case "mentionslegales" : {
            
            include("view/v_mentionLegales.php");
            break;

        }
        case "creationEntreprise" : {
           
            $nomForm= $_SESSION['nameFormulaire'];
           //////////////////////////////////////////////
                $ligne1=$pdo->idformulaire($nomForm);
                foreach ($ligne1 as $ligne) {
                    $idFormulaire=$ligne['ID_FORMULAIRE'];
                }
                $_SESSION['idForm']=$idFormulaire;
               
               $oui=$pdo->contenueFormulaire();
               $ligne1=$pdo->idContenueFormulaire();
               foreach($ligne1 as $ligne) {
                $idContenuFormluaire=$ligne['ID_CONTENU_FORMULAIRE'];
            }
            $_SESSION['idContenuFormluaire']=$idContenuFormluaire;


            include("view/formulaireMicroEntreprise/v_creationEntreprise.php");
            break;
        }


        case  "ValidationDossier" : {
            $idcontenu = $_REQUEST['idContenue'];
           
           $oui=$pdo->ValidationDossier($idcontenu);
           include("view/v_accueil.php");

        }
        case  "RefusDossier" : {
            $idcontenu = $_REQUEST['idContenue'];
            $non=$pdo->RefusDossier($idcontenu);

            include("view/v_accueil.php");
        }

        case "Detail" : {

            $idcontenu = $_REQUEST['idContenues'];
            $ligne2=$pdo->detailCommandeDashboardUtilisateur($idcontenu);
            include("view/v_detailDashboardUtilisateur.php");

        }
    }
}
?>