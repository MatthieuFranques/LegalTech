<?php
$action = $_REQUEST['action'];
if($action != ""){
    
    switch($action)
    {
        //Afficher la vue connexion
        case 'connexion' : {
            $login = "";
            $mdp = "";
            include("view/v_connexion.php");
            break;
        }
        
        //Vérifie la tentative de connexion
        case 'verifierConnexion':
        {   
        
            //verifier si login et mdp existe sinon met rien
            if(isset($_REQUEST['login']) && isset($_REQUEST['mdp'])){
                $login = $_REQUEST['login'];
                $mdp = $_REQUEST['mdp'];
            }
            else{
                $login = "";
                $mdp = "";
               
            }
            //Lance la connexion si il ya des valeurs de login mdp sont présente
            if($login != "" && $mdp != ""){
                $ok = $pdo->connexionLegalTech($login, $mdp);
                //Si connexion valide affiche la page correspondant au gérent ou non
                if($ok == true){
                    //SI le type et égal a  U ,A ,M renvoye vers sa page spécifié
                    if($_SESSION['connexion'] == 'U'){
                        $ligne1=$pdo->dashboardUEnTraitement();
                        $user=$pdo->dataUtilisateur();
                        $autre=$pdo->dashboardUAutre();
                       
                        include("view/v_dashboardUtilisateur.php");
                    }
                    if($_SESSION['connexion'] == 'A'){
                        $user=$pdo->dataUtilisateur();
                        $ligne1=$pdo->dashboardAEnTraitement();
                        $ligne2=$pdo->dashboardAAutre();
                        $autre=$pdo->dashboardA();
                        
                        include("view/v_dasboardAvocat.php");
                    }
                    if($_SESSION['connexion'] == 'M'){
                        $user=$pdo->dataUtilisateur();
                        include("view/v_dashboardMaster.php");
                    }
                }
                    else{
                        $erreur= "Saisie Incorecte";
                        include("view/v_erreur.php");
                          break;         
                    }
                 // function qui recup l'id de l'utilisateur ou autre 
                  
            }
           
            break;
        }


        //iscription pour l'utilisateur
        case 'inscription' : {
            //assignation des variable pour évité des message d'erreur dans les inputs du formulaire d'inscription
            $login="";
            $mdp="";
            $confmdp="";
            $nom="";
            $prenom="";
            $societe=""; 
            $mail="";
            $tel="";
               include("view/v_inscription.php");
            break;
        }

        //inscription utilisateur
        case 'inscriptionUtilisateur' : {
            $login=$_POST['login'];
            $mdp=$_POST['mdp'];
            $confmdp=$_POST['confmdp'];
            $nom=$_POST['nom'];
            $prenom=$_POST['prenom'];
            $mail=$_POST['mail'];
            $tel=$_POST['tel'];
            //mettre la règle des carctère spéciaux ('è_çàéù;,:!^$*=)
            if (caractereSpeciaux($nom)!=false) {
                $erreur="Des caractère non approprié ne sont pas toléré dans le nom";
                include("view/v_erreur.php");
                break;
                }
            if (caractereSpeciaux($prenom)!=false){
                $erreur="Des caractère non approprié ne sont pas toléré dans le prenom";
                include("view/v_erreur.php");
                break;
                }
            if (caractereSpeciaux($login)!=false){
                $erreur="Pas de caractère spéciaux dans le nom d'utilisateur";
                include("view/v_erreur.php");
                break;
                }
            //verif qu'il y est bien un @ dans le mail 
            if(verifmail($mail)!=true){
             $erreur="Il n'y a pas de @ dans votre adresse mail veuillez saisir un vrai adresse mail";
             include("view/v_erreur.php");
             break;
            }
            
            //verif mdp si il es identique
            if($mdp != $confmdp){

              $erreur="Erreur de saisie de mot de passe, veuillez saisir le même mot de passe dans les deux cases";
              include("view/v_erreur.php");
              //include("view/v_inscription.php");
              break;
            }
            // mettre le mdp a 15 caractère max règle a mettre  
            $inscriptionU = $pdo->incriptionUtilisateur($mail,$nom,$prenom,$tel);
            $ligne1= $pdo->idUtilisateurInscription();
            //utilisation du foreah pour recup ID_Utilisateur pour l'inscriptionConnexion
            foreach ($ligne1 as $ligne) {
                $idUser=$ligne['ID_UTILISATEUR'];
            }              
            $inscriptionC = $pdo->inscriptionConnexion($idUser,$login,$mdp);
            // mettre un if en cas de pb 
            $erreur="Votre compte a bien était crée";
            include("view/v_erreur.php");
            break;
        }




        //vérification de la session pour remplir un formulaire
        case 'verifSessionCreationEntreprise' : {
            //inscription formulaire
          
            $idformulaire="SASU";

            
               $_SESSION['nameFormulaire']=$idformulaire;
            if(verifSession()){ 
                header('Location: index.php?uc=service&action=creationEntreprise');
            }
            else {
                $erreur="Require une connexion pour accèder au formulaire";
                include("view/v_erreur.php");
            }
            break;
        }  


          //vérification de la session pour remplir un formulaire
          case 'verifSessionCreationEntreprise1' : {
            //inscription formulaire
          
            $idformulaire="EURL";

            
               $_SESSION['nameFormulaire']=$idformulaire;
            if(verifSession()){ 
                header('Location: index.php?uc=service&action=creationEntreprise');
            }
            else {
                $erreur="Require une connexion pour accèder au formulaire";
                include("view/v_erreur.php");
            }
            break;
        } 
          //vérification de la session pour remplir un formulaire
          case 'verifSessionCreationEntreprise2' : {
            //inscription formulaire
          
            $idformulaire="Micro-Entreprise";

            
               $_SESSION['nameFormulaire']=$idformulaire;
            if(verifSession()){ 
                header('Location: index.php?uc=service&action=creationEntreprise');
            }
            else {
                $erreur="Require une connexion pour accèder au formulaire";
                include("view/v_erreur.php");
            }
            break;
        } 
          //vérification de la session pour remplir un formulaire
          case 'verifSessionCreationEntreprise3' : {
            //inscription formulaire
          
            $idformulaire="SAS";

            
               $_SESSION['nameFormulaire']=$idformulaire;
            if(verifSession()){ 
                header('Location: index.php?uc=service&action=creationEntreprise');
            }
            else {
                $erreur="Require une connexion pour accèder au formulaire";
                include("view/v_erreur.php");
            }
            break;
        } 
          //vérification de la session pour remplir un formulaire
          case 'verifSessionCreationEntreprise4' : {
            //inscription formulaire
          
            $idformulaire="SARL";

            
               $_SESSION['nameFormulaire']=$idformulaire;
            if(verifSession()){ 
                header('Location: index.php?uc=service&action=creationEntreprise');
            }
            else {
                $erreur="Require une connexion pour accèder au formulaire";
                include("view/v_erreur.php");
            }
            break;
        } 
          //vérification de la session pour remplir un formulaire
          case 'verifSessionCreationEntreprise5' : {
            //inscription formulaire
          
            $idformulaire="SCI";

            
               $_SESSION['nameFormulaire']=$idformulaire;
            if(verifSession()){ 
                header('Location: index.php?uc=service&action=creationEntreprise');
            }
            else {
                $erreur="Require une connexion pour accèder au formulaire";
                include("view/v_erreur.php");
            }
            break;
        } 


        //vérification de la session pour accèder a son dashboard
        case 'dashboard' : {
            if(verifSession()){

                if($_SESSION['connexion'] == 'U'){
                    $user=$pdo->dataUtilisateur();
                    $ligne1=$pdo->dashboardUEnTraitement();
                    $autre=$pdo->dashboardUAutre();
                    include("view/v_dashboardUtilisateur.php");
                }
                if($_SESSION['connexion'] == 'A'){
                    $user=$pdo->dataUtilisateur();
                    $user=$pdo->dataUtilisateur();
                        $ligne1=$pdo->dashboardAEnTraitement();
                        $ligne2=$pdo->dashboardAAutre();
                        $autre=$pdo->dashboardA();
                    include("view/v_dasboardAvocat.php");
                }
                if($_SESSION['connexion'] == 'M'){
                    $user=$pdo->dataUtilisateur();
                    include("view/v_dashboardMaster.php");
                }   
            }
            else{ 
                $erreur="Require une connexion pour accèder au dashboard";
                include("view/v_erreur.php");
            }
            break;
        }



       //déconnexion de l'utilisateur
        case 'deconnexion':
            {   
                //Deconnexion si session ok 
                if(verifSession()){ 
                    supprSession();
                    header('Location: index.php?uc=connexion&action=connexion');
                }
                else{
                    //Sinon renvoye à la page d'accueil
                    header('Location: index.php?uc=Accueil');
                }
                break;
        }
    }
}
?>