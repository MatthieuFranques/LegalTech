<?php
$action = $_REQUEST['action'];
if($action != ""){
    
    switch($action)
    { 
        
        case 'page2' : {
            
            //mettre le numero de question
            
              $temps=$_POST['question1'];
              $_SESSION['contenu']=$temps;
              //function reponse question 
               $oui=$pdo->reponseFormulaire();
             
            include("view/formulaireMicroEntreprise/v_page2.php");break;
           
        }
        case 'page3' : {
            //mettre la fonction d'insertion
            
            $secteur=$_POST['question2'];
            $_SESSION['contenu']=$secteur;
               //function reponse question 
                $oui=$pdo->reponseFormulaire();
          
            include("view/formulaireMicroEntreprise/v_page3.php");break;
        }
        case 'page4' : {
          
            $nom=$_POST['question3'];
            $_SESSION['contenu']= $nom;
               //function reponse question 
            $oui=$pdo->reponseFormulaire();
          
            include("view/formulaireMicroEntreprise/v_page4.php");break;
        }

        case 'pageFin' : {
           
            $lieu = $_POST['question4'];
            $_SESSION['contenu']= $lieu;
               //function reponse question 
               $oui=$pdo->reponseFormulaire();
               
            $erreur="Votre demande a bien était pris en compte. <br> Un Avocat prendra votre demande en considération";
            include("view/v_erreur.php");
            break;

        }

    }



}