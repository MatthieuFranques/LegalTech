<?php
$action = $_REQUEST['action'];
if($action != ""){
    
    switch($action)
    { 
        
        case 'page2' : {
            
            //mettre le numero de question
            
              $temps=$_POST['question1'];
              $_SESSION['contenu']=$temps;
              //function reponse question 
               $oui=$pdo->reponseFormulaire();
             
            include("view/formulaireMicroEntreprise/v_page2.php");break;
           
        }

    }
}