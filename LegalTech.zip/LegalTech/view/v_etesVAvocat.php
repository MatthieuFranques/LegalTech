<style>
#navlist li { display:inline; padding:50px ; }
#navlist div { display:inline }</style>

<div style="background-color:#e3f0fd ;"><br>
<center><h1>Vous êtes avocat ?</h1></center>
<br>
</div>
<br>
<br>
<br>
<center><h2>Rejoindre notre réseau d'avocats partenaires</h2>
<p>Passez à la vitesse supérieure dans votre activité</p></center>
<br>
<br>
<center><button class="btn btn-success" style="padding:15px ;" >Devenir avocat partenaire</button></center>
<br><br>
<center><h2>Les 4 étapes pour intégrer notre réseau d'avocats partenaires</h2></center>
<BR><BR><BR>
<div style="margin: 0px 45px 0px; background-color: #F6F6F6; border-radius: 10px;" >
<ul id="navlist">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li><div style="font-size: 25px; color: red;">1</div></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li><div style="font-size: 25px; color: red;">2</div></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li><div style="font-size: 25px; color: red;">3</div></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li><div style="font-size: 25px; color: red;">4</div></li>
</ul>
<br><br>
<ul id="navlist">
<li style="background-color:#e8f0f8 ;"><div>Entretien avec un membre de l'équipe </div></li>&nbsp;
<li style="background-color:#e8f0f8 ;"><div>Etude de votre candidature</div></li>&nbsp;
<li style="background-color:#e8f0f8 ;"><div>Choix parmi nos plans avocat </div></li>&nbsp;
<li style="background-color:#e8f0f8 ;"><div>Entrée dans le réseau et premiers clients</div></li>
</ul>
<br><br><br><br>
<ul id="navlist">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li style="background-color:#e8f0f8 ;"><div>🕓 30min</div></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li style="background-color:#e8f0f8 ;"><div>🕓 48h</div></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li style="background-color:#e8f0f8 ;"><div>🕓 48h</div></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li style="background-color:#e8f0f8 ;"><div>🕓 24h</div></li>
</ul>
<br><br>
</div>
<br><BR><BR><BR>
<center><H2>Les avantages du réseau d’avocats</H2>
<br> <p>Les 3 forces de Legal Entreprise pour vous</p><br></center>
<div id="textDemarcheAvocat"> 
<div style="padding-left: 225px ;padding-right: 225px ;"> 
<h4><img src="images/visibilite.png"height="40 px" width="40 px"></img>&nbsp;&nbsp;&nbsp;Visibilité en ligne</h4>
</div> <div style="padding-left: 175px ;padding-right: 175px ;"> 
<b><p>Vous bénéficiez de notre site pour  : </p></b>
<p>-Etre visible en ligne</p> 
<p>-Recevoir des demandes de clients situés partout en France, et dans tous les domaines du droit de l’entreprise </p></div>
</div><br>
<div id="textDemarcheAvocat">
    <div style="padding-left: 225px ;padding-right: 225px ;">  
<h4><img src="images/client.png"height="40 px" width="40 px"></img>&nbsp;&nbsp;&nbsp;Développez votre clientèle</h4>
</div> <div style="padding-left: 175px ;padding-right: 175px ;"> 
<b><p>Notre référencement permet de : </p></b>
<p>-Transformer des leads qualifiés en nouveaux clients </p>
<p>-Recevoir des demandes de mises en relation dans votre domaine d'expertise </p> </div>
</div> <br>
<div id="textDemarcheAvocat">
    <div style="padding-left: 225px ;padding-right: 225px ;"> 
<h4><img src="images/reseau.png"height="40 px" width="40 px"></img>&nbsp;&nbsp;&nbsp;Réseau sélectif</h4>
</div> <div style="padding-left: 175px ;padding-right: 175px ;"> 
<b><p>Rejoindre notre réseau vous permet : </p></b>
<p>-D'intégrer une communauté d’avocats reconnue </p>
<p>-Etre réuni autour d’une volonté commune d’aider toutes les entreprises, quelle que soit leur taille, dans la résolution de leurs problématiques juridiques </p>
 </div></div><br>
 <br><br>

<center><button class="btn btn-success" style="padding:15px ;" >Devenir avocat partenaire</button></center>
<br><br><br>


  
