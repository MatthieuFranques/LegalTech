<?php  $i=0;
foreach($ligne2  as $ligne) {
       $contenu=$ligne['CONTENU'];
       $info = array("L'adresse","Nom société","Secteur d'activité","Délais");
      $id=$info[$i];
    ?>

<p><B><?=$id." : "?>  </B><?=$contenu ?></p>
<?php $i++; } ?>

<br>
<a href="index.php?uc=connexion&action=dashboard" class="btn btn-danger">Retour</a>
