<link rel="stylesheet" href="css.css" type="text/css">
<style>
#navlist li { display:inline}
#navlist div { display:inline }</style>
<div class="offre"> 

<div style="background-color:#e3f0fd ;"><br>
<center><h1>Nos offres</h1></center>
<br>
</div>

   <tr>
       <td> 
           <!--  changé les checkbox par des radios  et ajouté le script de tableau.js-->
<!-- <input type="radio" name="check" onclick="show('CE');" value="CE" id="oui">création d'entreprise
<input type="radio" name="check" onclick="show('CO');" value="CE" id="non">autre -->
<br>
<center><h1>Créer son entreprise en toute sérénité</h1>
<br>
<p>Un accompagnement adapté à tous les entrepreneurs : simplicité, rapidité et expertise.</p><br><br></center>
<div style=" background-color: #F6F6F6; border-radius: 10px; margin-left: 350px; margin-right: 350px;" >
<br>
<br>
<ul id="navlist">
<li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div><b style="font-size:18px;">Je me lance seul</b></div></li> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li><div><b style="font-size:18px;">Je me lance à plusieurs</b></div></li>&nbsp;
</ul>
<br><br>
<ul id="navlist">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li class="offreE"><a href="index.php?uc=connexion&action=verifSessionCreationEntreprise"  style=" color:white; text-decoration: none; padding:2px;"  id="SASU"  value="SASU" name="SASU"  >SASU </a></li>&nbsp;&nbsp;&nbsp;&nbsp;
<li class="offreE"><a href="index.php?uc=connexion&action=verifSessionCreationEntreprise1"  style=" color:white; text-decoration: none; padding:2px;" id="EURL"  value="EURL" name="EUL">EURL</a></li>&nbsp;&nbsp;&nbsp;&nbsp;
<li class="offreE"><a href="index.php?uc=connexion&action=verifSessionCreationEntreprise2"  style=" color:white; text-decoration: none;"id="Micro-Entreprise"  value="Micro-Entreprise" name="Micro-Entreprise" >Micro-Entreprise</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<li class="offreE"><a href="index.php?uc=connexion&action=verifSessionCreationEntreprise3"  style=" color:white; text-decoration: none; padding:2px;" id="SAS"  value="SAS" name="SAS"  >SAS</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li class="offreE"><a href="index.php?uc=connexion&action=verifSessionCreationEntreprise4"  style=" color:white; text-decoration: none; padding:2px;" id="SARL"  value="SARL" name="SARL">SARL</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li class="offreE"><a href="index.php?uc=connexion&action=verifSessionCreationEntreprise5"  style=" color:white; text-decoration: none; padding:2px;" id="SCI"  value="SCI" name="SCI">SCI </a></li>&nbsp;
</ul>
<br>


<br><br></div>
<br><br><br>

<center><h1>La gestion de vos litiges en toute sécurité</h1>
<br>
<p>Legal Entreprise gèrent quotidiennement leur entreprise avec nous</p><br><br></center>
<div style=" background-color: #F6F6F6; border-radius: 10px; margin-left: 350px; margin-right: 350px;" >
<br>
<br>
<br>
<ul id="navlist">
&nbsp;&nbsp;&nbsp;&nbsp;<li class="offreE"><a href="#"  style=" color:white; text-decoration: none; padding:2px;"  id="Dissolution-Radiation "  value="Dissolution-Radiation " name="option"  >Dissolution-Radiation  </a></li>&nbsp;&nbsp;&nbsp;&nbsp;
<li class="offreE"><a href="#"  style=" color:white; text-decoration: none; padding:2px;" id="Mise en demeure de recouvrement "  value="Mise en demeure de recouvrement " name="option">Mise en demeure de recouvrement </a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li class="offreE"><a href="#"  style=" color:white; text-decoration: none; padding:2px;" id="Assignation en contrefaçon"  value="Assignation en contrefaçon" name="option">Assignation en contrefaçon</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</ul>
<br>
<br>
<ul id="navlist">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li class="offreE"><a href="#"  style=" color:white; text-decoration: none;"id="Injonction de payer"  value="Injonction de payer" name="option" >Injonction de payer</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li class="offreE"><a href="#"  style=" color:white; text-decoration: none; padding:2px;" id="Injonction de faire"  value="Injonction de faire" name="option"  >Injonction de faire</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</ul>

<br><br><br></div>
<br>
<p style="color:red; font-size:18px; text-align: center;">En cours de développement</p>
<a class="nav-link" style="color:#FFFF;" href="#"> Découvrez tous nos tarif </a>
</div>
<br><br><br><br>
</div>  