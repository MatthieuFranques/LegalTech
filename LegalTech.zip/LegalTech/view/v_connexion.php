  <div class="connexion"><form method="post" action="index.php?uc=connexion&action=verifierConnexion" class="animate__animated animate__fadeInDown">
  
<h2>Connexion</h2>
<br>
<input type="text" name="login" class="form-control" placeholder="Nom Uilisateur"value="<?=$login ?>" REQUIRED>
<br>
<BR>
<input type="password" name="mdp"class="form-control" placeholder="Mot de passe"value="<?=$mdp ?>" REQUIRED>
<br>
<BR>
<input type="submit" name="btnconnexion"  class="btn btn-primary">
<br>
<br>
<a href="index.php?uc=connexion&action=inscription">Inscription</a>
<br><br><br><br><br>
</form></div>


