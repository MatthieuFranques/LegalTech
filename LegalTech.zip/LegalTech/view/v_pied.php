<div class="bas">
      <table style=" 
    border-collapse: separate;
    border-spacing: 120px 0px;"> 
          <tr> 
              <th><p style="color:#FFFF ;">CONTACT</p>  </th>
              <th><P style="color:#FFFF ;">A PROPOS </P> </th>
              <th><P style="color:#FFFF ;">LIENS UTILIES</P> </th>
              <th><P style="color:#FFFF ;">NOS RESEAUX</P> </th>

</tr>
<tr>
      <th><p style="color:#FFFF ; font-size:12px ;">Mail: contact@legalentreprise.fr<p> </th>
      <th><a class="nav-link" style="color:#FFFF; font-size: 12px ;" href="index.php?uc=service&action=mentionslegales">Mentions légales</a></th>
      <th><a class="nav-link" style="color:#FFFF; font-size: 12px ;" href="index.php?uc=Accueil">Accueil</a></th>
      <th><a class="nav-link" style="color:#FFFF; font-size: 12px ;" href="#"><img src="images/linkedin.png" height="30px" width="30px"></img></a></th>
</tr>
</tr>
<tr>
      <th> <p style="color:#FFFF ; font-size: 12px ;">Téléphone: 01 24 43 23 45 </p> </th>
      <th></th>
      <th><a class="nav-link" style="color:#FFFF; font-size: 12px ;" href="index.php?uc=connexion&action=connexion">Se connecter</a></th>
      <th><a class="nav-link" style="color:#FFFF; font-size: 12px ;" href="#"><img src="images/instagram.png"height="30px" width="30px"></img></a></th>
</tr>
     <br><br>  
       </div>
</body>
