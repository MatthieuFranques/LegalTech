
<div class="connexion"><form method="post" action="index.php?uc=connexion&action=inscriptionUtilisateur">
  
<h2>Inscription</h2>
<br>
Nom : <input type="text" name="nom" class="form-control" placeholder="Votre nom" REQUIRED>

Prenom : <input type="text" name="prenom"class="form-control" placeholder="Votre prenom" REQUIRED>


Mail : <input type="text" name="mail"class="form-control" placeholder="Votre mail" REQUIRED>

Téléphone : <input type="text" name="tel"class="form-control" placeholder="Votre numéro de téléphone" REQUIRED>

Nom d'utilisateur : <input type="text" name="login" class="form-control" placeholder="Nom Uilisateur"  REQUIRED>

Mot de passe : <input type="password" name="mdp"class="form-control" placeholder="Mot de passe"  REQUIRED>

Confirmation mot de passe : <input type="password" name="confmdp"class="form-control" placeholder="Mot de passe"  REQUIRED>
<br> 

<input type="submit" name="inscription"  class="btn btn-primary">

</form></div>
