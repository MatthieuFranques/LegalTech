<link rel="stylesheet" href="view/v_css.css" type="text/css">
<div class="voirTarif"> 
<div style="background-color:#e3f0fd ;"><br>
<center><h1>Tarifs</h1></center>
<br>
</div>
<br>
<h2>Création de Société</h2>

<table class="table table-striped table-bordered table-sm"> 
<thead>
<tr>
<th scope="col">Nom</th>
<th scope="col">Tarif</th>
</tr> 
</thead>
<tbody>
<?php
foreach ($ligne1 as $ligne) {
 
     $libelle=$ligne['LIBELLE']; 
     $cout = $ligne['COUT'];
    
?>
<tr>
<td><?=$libelle ?></td>
<td><?=$cout."€"?></td>
</tr>


<?php }?>
</tbody>
</table>
<br>
<h2>Gestion litige</h2>
<table class="table table-striped table-bordered table-sm" > 
<thead>
<tr>
<th scope="col">Nom</th>
<th scope="col">Tarif</th>
</tr> 
</thead>
<tbody>
<?php
foreach ($ligne2 as $ligne) {
 
     $libelle=$ligne['LIBELLE']; 
     $cout = $ligne['COUT'];
    
?>
<tr>
<td><?=$libelle ?></td>
<td><?=$cout."€"?></td>
</tr>


<?php }?>
</tbody>
</table>


<br><br>
<div id="vert" style="
    margin-right:1370px; border-radius: 17px;">
<a class="nav-link" style="color:#FFFF;" href="index.php?uc=service&action=offre"> Voir nos offres </a>
</div>
<br><br><br>
</div> 