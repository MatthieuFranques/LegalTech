<div style="background-color:#e3f0fd ;"><br>
<center><h1>Mentions Légales </h1></center>
<br>
</div>
<br>
<div style="padding-right:375PX; padding-left:100px ;">
<p>Conformément aux dispositions de la loi n° 2004-575 du 21 juin 2004 pour la confiance en l'économie numérique, 
il est précisé aux utilisateurs du Site l'identité des différents intervenants dans le cadre de sa réalisation et de son suivi.</p>

<h2> Édition du site </h2>
<br>
<p>Le site legalentreprise.fr est édité par la Micro-Entreprise legalentreprise, au capital social de 0 € euros, 
immatriculée au Registre du commerce et des sociétés de Paris sous le n° 12345678 et dont le siège social est situé Toulouse 31000
 (Siret n° 435 567 876 00047).</p>

<h2> Responsable de publication </h2>
<br>
 <p>Monsieur Franques Matthieu</p>

<h2>Hébergeur</h2>
<br>
<p>Le site legalentreprise.fr est hébergé par la société Amazon Web Services LLC
Adresse: P.O. Box 81226, Seattle, WA 98108-1226</p>

<h2>Nous contacter</h2> 
<br>
<p>Par téléphone : 01 21 23 00 00</p>
<p>Par email : contact@legalentreprise.fr</p>
<p>Par courrier : legalentreprise.fr , Toulouse 31000</p>
<br><br>
</div>