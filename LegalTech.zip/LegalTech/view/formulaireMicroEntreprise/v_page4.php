<div class="progress">
<div class="progress-bar" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
</div>
<div style="background-color:#e3f0fd ;"><br>
<center><h1>Création Entreprise </h1></center>
<br>
</div>
<br
<div class="creationEntreprise">
<form method="POST" action="index.php?uc=creationEntreprise&action=pageFin"> 

<b><p name="p" id="p" value="1"style="font-size:20px;">Ou se trouvera La société?</p> </b>
<!--Utilisé une API du gouv pour les adresses-->
<input type="text" name="question4" class="form-control" placeholder="Lieu société">
<br>
<br><br><br><br><br>
<input type="submit" class="btn btn-danger" value="Suivant">

</form>
</div>