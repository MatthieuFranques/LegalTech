<div class="progress">
  <div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
</div>
<div style="background-color:#e3f0fd ;"><br>
<center><h1>Création Entreprise </h1></center>
<br>
</div>
<br>
<div class="creationEntreprise">
<form method="POST" action="index.php?uc=creationEntreprise&action=page4"> 

<b><p name="p" id="p" value="1"style="font-size:20px;">Quel sera le nom de la société?</p></b> 

<input type="text" name="question3" class="form-control" placeholder="Votre secteur d'activité">
<br>
<input type="submit" class="btn btn-danger" value="Suivant">

</form>
</div>
<BR><BR><BR><BR><BR><BR><BR>