<div class="progress">
  <div class="progress-bar" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
</div>
<div style="background-color:#e3f0fd ;"><br>
<center><h1>Création Entreprise </h1></center>
<br>
</div>
<br>
<div class="creationEntreprise">
<form method="POST" action="index.php?uc=creationEntreprise&action=page2"> 

<b><p name="p" id="p" value="1"style="font-size:20px;">Dans combien de temps voulez-vous commencé votre activité ?</p> </b>

Dès que possible<input class="form-check-label" type="radio" value="Dès que possible" name="question1" ><br>
Moins de 3 mois<input class="form-check-label" type="radio" value="Moins de 3 mois" name="question1" ><br>
Plus de 3 mois<input class="form-check-label" type="radio" value="Plus de 3 mois"  name="question1"><br>
<br>
<input type="submit" class="btn btn-danger" value="Suivant">

</form>
</div>
<BR><BR><BR><BR><BR><BR><BR>