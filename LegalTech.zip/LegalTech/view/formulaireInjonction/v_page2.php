<div class="creationEntreprise">
<h1>Injonction</h1>

<form method="POST" action="index.php?uc=creationEntreprise&action=page3"> 

<p name="p" value="2">Informations vous concernant</p> 

Une société commerciale (SARL/EURL, SAS/SASU)<input class="form-check-label" type="radio" value="une société commerciale (SARL/EURL, SAS/SASU)" name="question1" ><br>
Un entrepreneur individuel (auto-entrepreneur, EI, EIRL)<input class="form-check-label" type="radio" value="un entrepreneur individuel (auto-entrepreneur, EI, EIRL)" name="question1" onclick="show('partie1')" ><br>
une société civile (SCI, SC, SCP, SCM)<input class="form-check-label" type="radio" value="une société civile (SCI, SC, SCP, SCM)" name="question1" onclick="show('partie1')" ><br>
une profession libérale<input class="form-check-label" type="radio" value="une profession libérale" name="question1" onclick="show('partie1')" ><br>
<br>
<input type="submit" class="btn btn-danger" value="Suivant">

</form>
</div>

<BR><BR><BR><BR><BR><BR><BR>