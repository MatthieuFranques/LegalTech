<div class="creationEntreprise">
<h1>Injonction</h1>

<form method="POST" action="index.php?uc=creationEntreprise&action=page3"> 

<p name="p" value="2">Montant de l'injonction</p> 

<input type="text" name="question2" class="form-control" placeholder="Somme impayé">
<br>
<input type="date" name="question2" class="form-control">
<input type="submit" class="btn btn-danger" value="Suivant">

</form>
</div>

<BR><BR><BR><BR><BR><BR><BR>