<head><script type="text/javascript" src="javascript.js"></script> </head>
<div class="creationEntreprise">

<h2>Injonction</h2>

<form method="POST" action="index.php?uc=creationEntreprise&action=page2"> 

<p name="p" id="p" value="1">Quel impayé souhaitez-vous récupérer?
</p> 

Une facture impayée<input class="form-check-label" type="radio" value="Une facture impayée" name="question1" ><br>
Un loyer impayé<input class="form-check-label" type="radio" value="Un loyer impayé" name="question1" onclick="show('partie1')" ><br>
<div id="partie1" style="display : none">
<strong>Service en cours de développement</strong>
<P>Notre procédure n'est pas encore adaptée pour récupérer un loyer impayé. Nous pouvons vous mettre en relation avec un professionnel du droit (avocat, huissier).</P>
</div>
Un chèque impayé<input class="form-check-label" type="radio" value="Un chèque impayé"  name="question1" onclick="show('partie2')"><br>
<div id="partie2" style="display : none">

<strong>Service en cours de développement</strong>
</p>Notre procédure n'est pas adaptée pour récupérer un chèque impayé (chèque sans provision). Nous vous recommandons d'utiliser une procédure spécifique simplifiée, dont les étapes sont décrites ci-dessous.</p>
<p>1. Attestation de rejet de chèque
Votre banque informe le débiteur par le biais d'une attestation de rejet de chèque pour défaut de provision.
</p><p>2. Courrier RAR au débiteur
Dans un délai de 30 jours, vous pouvez adresser une demande au débiteur par recommandé avec avis de réception afin que ce dernier :
- paye par un autre moyen de paiement (espèces, virement, ...) ou ;
- alimente son compte pour que votre banquier puisse encaisser le chèque.
</p><p>3. Certificat de non-paiement
Si la somme n'a toujours pas été payée dans un délai de 30 jours, vous pouvez enclencher une procédure de paiement à l'encontre du débiteur. Pour ce faire, vous devez demander un certificat de non-paiement à votre banque.
</p><p>4. Signification et saisie par huissier
Vous devez ensuite vous adresser à un huissier pour qu'il signifie le certificat de non-paiement au débiteur. Cette signification vaut "injonction de payer". Si dans un délai de 15 jours la situation n'est toujours pas régularisée, la formule exécutoire est apposée sur le certificat de non-paiement. Ce document devient alors un titre exécutoire permettant d'engager une saisie par huissier. Les frais d'huissier sont payés par le débiteur.
</p></div>
<br>
<input type="submit" class="btn btn-danger" value="Suivant">

</form>
</div>
<BR><BR><BR><BR><BR><BR><BR>