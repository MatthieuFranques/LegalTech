<h1>dashboardAvocat</h1>


<h2>En attente</h2>
<table class="table table-striped">
<thead>
  <tr>
  <th>#</th> 
    <th>Nom </th>  
    <th>Prenom</th>
    <th>Nom Service</th> 
    <th>Etat</th>   
    <th>Statut</th>   
  </tr>
</thead>
<tbody>
<?php $i=1;$btn;
foreach($ligne1 as $ligne) {
    
    $nom=$ligne['NOM'];
    $prenom=$ligne['PRENOM'];
    $Libellef=$ligne['LIBELLE'];
    $Libellee=$ligne['LIBELLEE'];
    $idcontenue=$ligne['ID_CONTENU_FORMULAIRE'];
?>  

  <tr>
      <th><?=$i?></th>
    <th><?=$nom?></th>  
    <th><?=$prenom ?></th>  
    <th><?=$Libellef ?></th>  
    <th><?=$Libellee ?></th>  
    <th> <a href="index.php?uc=service&idContenues=<?=$idcontenue?>&action=Detail" class="btn btn-success" >Détail</a></th>
    <th> <a href="index.php?uc=service&idContenue=<?=$idcontenue?>&action=ValidationDossier" class="btn btn-success" onClick="return confirm('Voulez-vous valider se service ?')">Validé</a></th>
    <th><a href="index.php?uc=service&idContenue=<?=$idcontenue?>&action=RefusDossier"  class="btn btn-danger" onClick="return confirm('Voulez-vous refuser se service ?')">Refusé</a></th>
  </tr>
  <?php $i++; } ?>
</tbody>

</table>
<br<<br><br>
<h2> Historique
</h2>
<table class="table table-striped">
<thead>
  <tr>
  <th>#</th> 
    <th>Nom </th>  
    <th>Prenom</th>
    <th>Nom Service</th> 
    <th>Etat</th>   
    <th>Statut</th>   
  </tr>
</thead>
<tbody>
<?php $iI=1;$btn;
foreach($ligne2 as $ligneS) {
    
    $nom2=$ligneS['NOM'];
    $prenom2=$ligneS['PRENOM'];
    $Libellef2=$ligneS['LIBELLE'];
    $Libellee2=$ligneS['LIBELLEE'];
    $idcontenue2=$ligneS['ID_CONTENU_FORMULAIRE'];
?>  

  <tr>
      <th><?=$iI?></th>
    <th><?=$nom2?></th>  
    <th><?=$prenom2 ?></th>  
    <th><?=$Libellef2 ?></th>  
    <th><?=$Libellee2 ?></th>  
    <th> <a href="index.php?uc=service&idContenues=<?=$idcontenue2?>&action=Detail" class="btn btn-success" >Détail</a></th>
  </tr>
  <?php $iI++; } ?>
</tbody>
</table>



<!--Crée un tableau avec tous les clients avec l'état en cours avec le nom du formualaire demandé -->

<!--Crée un tableau archive avec tous les formulaire déjà traité  avec nomUtilisateur,TypeForm,LibelleFormulaire, état, -->
<!--A chaque formulaire remplir <h1>TypeForm,NomForm,DAte</h1> une list ou un tableau avec toute les info sur le client Nom, prenom, mail ,tel,et les réponce au formulaire-->
<!-- avec la possibilite de pouvoir imprimé chaque tableau jquery datatable -->