<link rel="stylesheet" href="css.css" type="text/css">
<style>
.popup .overlay {
  position:fixed;
  top:0px;
  left:0px;
  width:100vw;
  height:100vw;
  background:rgba(232,232,232);
  opacity: 0.33;
  z-index:1;
  display:none;
}
.popup .content { 
  position: absolute;
  top:50%;
  left:50%;
  transform:translate(-50%,-50%) scale(0);
  background:#fff;
  width: 550PX;
  height: 250px;
  z-index: 2;
  text-align:center;
  padding:20px;
  box-sizing:border-box;
  border-radius: 10px;
}
.popup .close-btn{
  position:absolute;
  right:20px;
  top:20PX;
  width:35px ;
  height:35px;
  background:#222;
  color:#fff; 
  font-size:25px;
  font-weight:600;
  line-height:30px;
  text-align:center;
  border-radius:45%;
}
.popup.active .overlay{
  display: block;
}
.popup.active .content{
  transition:all 300ms ease-in-out;
  transform:translate(-50%,-50%) scale(1);
}
#presentationU{
  padding-left:1100px;
}
</style>
<script>
function togglePopup(){
    document.getElementById("popup").classList.toggle("active");
} </script>
<?php foreach($user as $ligne) {
  $i=1;
  $a=1;
    $nom=$ligne['NOM'];
    $prenom=$ligne['PRENOM'];


 ?>
<P id="presentationU">Bienvenue dans votre espace client <?=$prenom."  ".$nom ?></P>

<h4>Service en attente<h4>
<BR>
<table class="table table-striped table-bordered table-sm">
<thead>
  <tr>
    <th>#</th>
    <th>Nom Service</th>  
    <th>Etat</th>
    <th>Détail</th>   
  </tr>
</thead>
<tbody>
  
  <?php    
foreach($ligne1 as $ligne) {
  $idLibellef=$ligne['LIBELLE'];
  $idLibellee=$ligne['LIBELLEE'];
  $idcontenue=$ligne['ID_CONTENU_FORMULAIRE'];

?> 
  <tr>
  <th><?=$i?></th>
    <th><?=$idLibellef?></th>  
    <th><?=$idLibellee ?></th>  
    <th> <a href="index.php?uc=service&idContenues=<?=$idcontenue?>&action=Detail" class="btn btn-success" >Détail</a></th>
  <?php $i++; } ?>
</tbody>
</table>
<BR>
<H4>AUTRE</H4>
<table class="table table-striped">
<thead>
  <tr>
    <th>#</th>
    <th>Nom Service</th>  
    <th>Etat</th>
    <th>Détail</th>   
  </tr>
</thead>
<tbody>
  
  <?php    
foreach($autre as $ligne) {
 
  $idLibellef=$ligne['LIBELLE'];
  $idLibellee=$ligne['LIBELLEE'];
  $idcontenue=$ligne['ID_CONTENU_FORMULAIRE'];

?> 
  <tr>
  <th><?=$a?></th>
    <th><?=$idLibellef?></th>  
    <th><?=$idLibellee ?></th>  
    <th> <a href="index.php?uc=service&idContenues=<?=$idcontenue?>&action=Detail" class="btn btn-success" >Détail</a></th>
  </tr>
  <?php $a++; } }?>
</tbody>
</table>
<!-- -->
<div class="popup" id="popup">
<div class="overlay"></div> 
<div class="content">

<div class="close-btn"  onclick="togglePopup()">&times;</div> 
<h3>Détail du service </h3> 

<?php  $i=0;
foreach($ligne2  as $ligne) {
       $contenu=$ligne['CONTENU'];
       $info = array("Délais","Secteur d'activité","Nom société","L'adresse");
      $id=$info[$i];
    ?>

<p><B><?=$id." : "?>  </B><?=$contenu ?></p>
<?php $i++; } ?>
<br>
</div></div> <br>
<!-- -->


<BR><BR><BR>
  <!--Crée un tableau avec le LibelleFormulaire la date de l'inscription au form et l'état du formulaire en cours pris en compte validé  -->

<!-- si l'Utilisateur a dèja des services qui on était déjà validé ou autre -->
<!-- ON les affiche dans un tableau avec le TypeForm, NomForm-->
<!-- Dès qu'on click sur un ligne si nous affiche les détail de ce service-->
