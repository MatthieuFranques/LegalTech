 <script> 
var i = 0;
var images = [
'images/image.png','images/fond1.jpg' ,'images/fond2.jpg'] ;
var time = 75000000;

function changeImg(){

document.slide.src = images[i];

if (i < images.length - 1) {
i++;
} else {
i = 0;
}
setTimeout("changeImg()", time);
}
window.onload = changeImg;

</script>
<style> 
#image{  
  height:425px; 
  width:1190px;
  position:absolute;
  top:18%;
  left:10%;
  transform: translate(-50%,-50%);
}
</style>
<br>
<!--class="animate__animated animate__fadeInDown"  height="325 px" width="1200 px" -->
<img id="image" name="slide" class="animate__animated animate__fadeInDown">
<br>
<br>

<br><br><br><br> <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div id="textaccueil"  class="animate__animated animate__fadeInDown"> 
<div class="linear-gradient">
<h2>La LegalTech?</h2>
<br>
<p> En pratique il est plus cohérent de parler de transformation digitale du droit, les legaltech utilisant la technologie et les logiciels pour automatiser et délivrer des services juridiques.</p>
<p> Les premières legaltech sont apparues aux Etats-Unis dans les années 2000.</p>
<p> En France, les premières legaltech ont fait leur apparition début 2013, et le terme d’uberisation du droit a fait son apparition. </p>
</div>
</div>
<br>
<div class="linear-gradient2">  
<div class="animate__animated animate__fadeInDown"> 
<br><br>
<center><H2>Comment ça marche ?</H2>
<br><br>
<div id="textDemarcheAccueil"> 
<h4><img src="images/choisir.png"height="40 px" width="40 px"></img>&nbsp;&nbsp;&nbsp;Choisissez la démarche adaptée</h4>
<p>Utilisez nos outils pour définir le service qui vous va le mieux. C’est simple et rapide.</p>
</div> <br>
<div id="textDemarcheAccueil">
<h4><img src="images/formulaire.png"height="40 px" width="40 px"></img>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Remplissez un formulaire</h4>
<p>Répondez à quelques questions sur votre projet et générez automatiquement les documents-clés de votre démarche (formulaires...).</p>
</div> <br>
<div id="textDemarcheAccueil">
<h4><img src="images/ocupe.png"height="40 px" width="40 px"></img>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;On s'occupe de tout !</h4>
<p>Nos experts vérifient votre dossier et gèrent tous les échanges avec les administrations compétentes (greffes, préfectures, INPI...) jusqu'à la finalisation de votre démarche.</p>
</div><br>
<div id="textDemarcheAccueil">
    
<h4><img src="images/main.png"height="40 px" width="40 px"></img>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;On vous accompagne de A à Z</h4>
<p>Besoin de renseignement ou d'assistance dans votre démarche ? Nos experts se feront un plaisir de vous aider. N'hésitez pas, appelez-les. </p>
</div> 
<br>
<br>
  <div id="vert" style="margin-left:640px ;
    margin-right:640px; border-radius: 17px;">
<a class="nav-link" style="color:#FFFF;" href="index.php?uc=service&action=offre"> Découvrir toutes nos offres </a>
</div><br><br></center>
</div>

  </div>  

