<div class="erreur">
<h2 class="animate__animated animate__flash"><?=$erreur;?></h2>
<br><br>
<form action="index.php?uc=Accueil">
<input type="submit" class="btn btn-danger"  value="Retour">
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</form>
</div>

