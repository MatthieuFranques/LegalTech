<?php
//Fonction qui verifie si il y a déjà une connexion
function verifSession (){
    if(isset($_SESSION['ok']) )
    {     //si ok = oui renvoi true 
        if($_SESSION['ok'] == 'oui'){
            return true;
        }
        //sinon renvoye faux
        else{
            return false;
        }
    }
    else{
        return false;
    }
}
//Fonction Deconnexion
function supprSession(){
    session_destroy();
    $_SESSION['ok'] = "non";
}

function verifmail($mail){
    if(stristr($mail, '@')) {
        return true;
       }
       else{
           return false;
       }
}

// mise en place d'une fonction filtrant les caractère spéciaux 
function caractereSpeciaux($string) {
    

    if(stristr($string, '"/@?:!&"(_)=$*;,')) {
        return true;
       }
       else{
           return false;
       }

}
?>