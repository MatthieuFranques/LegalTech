<?php
class PDOLegalTech

{   		
      	private static $monPdo;
		private static $monPDOLegalTech = null;
/**
 * Constructeur privé, crée l'instance de PDO qui sera sollicitée
 * pour toutes les méthodes de la classe
 **/				
	private function __construct()
	{
    	PDOLegalTech::$monPdo = new PDO('mysql:host=127.0.0.1;dbname=legaltech', 'root', ''); 
		PDOLegalTech::$monPdo->query("SET CHARACTER SET utf8");
	}
	public function _destruct(){
		PDOLegalTech::$monPdo = null;
	}
/**
 * Fonction statique qui crée l'unique instance de la classe
 *
 * Appel : $instancePDOForma = PDOLegalTech
 * ::getPDOForma();
 * @return l'unique objet de la classe PDOLegalTech
 * 
 */
	public  static function getPDOLegalTech()
	{
		if(PDOLegalTech::$monPDOLegalTech == null)
		{
			PDOLegalTech::$monPDOLegalTech= new PDOLegalTech();
		}
		return PDOLegalTech::$monPDOLegalTech;  
    }
    //Requête de connexion
    public static function connexionLegalTech($login,$mdp)
    {
        
        $sql = "SELECT ID_UTILISATEUR,MDP,TYPEC FROM connexion WHERE LOGIN='$login'";
       
        $res = PDOLegalTech::$monPdo->query($sql);
        $ligne = $res->fetch();
        $motPasse = $ligne['MDP'];
        $idUser= $ligne['ID_UTILISATEUR'];
       
        $TYPE = $ligne['TYPEC'];
      
      //si le mdp et different de rien 
        if ($mdp != ""){
            //si mdp et different du mot de passe de la BDD 
            if  ($motPasse != $mdp)
            { 
                //On retourne faux
                 
                return false; 
            }
            else
            {
                $_SESSION['idUser']= $idUser;
                $_SESSION['ok'] = 'oui';
                //si le type et egal a u alors on renvoye u pour utilisateur   
                if($TYPE == 'U')
                {
                    $_SESSION['connexion'] = 'U';
                }
                if($TYPE == 'A')
                {
                    $_SESSION['connexion'] = 'A';
                }
                if($TYPE == 'M')
                {
                    $_SESSION['connexion'] = 'M';
                }
               
                ob_end_flush();
                return true;
            }
        }   
        else
        {
            return false;
        }
    }
    public static function inscriptionConnexion($idUser,$login,$mdp){
          
        $sql="INSERT INTO connexion Values(ID_CONNEXION,$idUser,'$login','$mdp','U');";
        
        $res = PDOLegalTech::$monPdo->exec($sql);
    }
 
    public static function incriptionUtilisateur($mail,$nom,$prenom,$tel){
        
        $sql="INSERT INTO utilisateur Values(ID_UTILISATEUR,'$nom','$prenom','$mail','$tel');";
        $res = PDOLegalTech::$monPdo->exec($sql);	
       
    } 
    //recup de l'id pour l'inscription
    public static function idUtilisateurInscription(){
        
        // req qui affiche toute la table utilisateur pour l'id le plus grand 
        //car on inscript d'abord dans la table user puis connexion c pour ca qu'on prend la dernière id
        $sql= "SELECT * FROM utilisateur WHERE ID_UTILISATEUR = (SELECT MAX(ID_UTILISATEUR) FROM utilisateur);";
        $res = PDOLegalTech::$monPdo->query($sql);
        $ligne1 = $res->fetchAll();
        return $ligne1;
    }
    //affichage des information de l'utilisateur
    public static function dataUtilisateur(){
        $iduser=$_SESSION['idUser'];
        $sql= "SELECT * FROM utilisateur WHERE ID_UTILISATEUR =$iduser;";
        $res = PDOLegalTech::$monPdo->query($sql);
        $user = $res->fetchAll();
        return $user;
    }

    //Affichage des prix de chaque offre suivant ce qu'il y a en base de donnée
    public static function tarif(){
         $sql="SELECT LIBELLE,COUT FROM tarif,formulaire WHERE formulaire.ID_FORMULAIRE = tarif.ID_FORMULAIRE AND TYPE='CE';";
      
         $res = PDOLegalTech::$monPdo->query($sql);
         $ligne1 = $res->fetchAll();
         return $ligne1;
    }
    public static function tarif1(){
        $sql="SELECT LIBELLE,COUT FROM tarif,formulaire WHERE formulaire.ID_FORMULAIRE = tarif.ID_FORMULAIRE AND TYPE='CO';";
     
        $res = PDOLegalTech::$monPdo->query($sql);
        $ligne1 = $res->fetchAll();
        return $ligne1;
   }
    // req qui affiche le nom de formulaire suivant son type 
    public static function nom($TYPE){
        $sql="SELECT LIBELLE FROM formulaire where TYPE=$TYPE;";
        $res = PDOLegalTech::$monPdo->query($sql);
         $ligne1 = $res->fetchAll();
         return $ligne1;
    }
    //req qui affcihe l'id du formulaire selectionné
    public static function idformulaire($nomForm){
        $sql="SELECT * FROM formulaire where LIBELLE='$nomForm';";
        $res = PDOLegalTech::$monPdo->query($sql);
         $ligne1 = $res->fetchAll();
         return $ligne1;
    }



    //fonction qui inscrit l utilisateur dans la table inscription et qui l'inscrit aussi dans la table contenu_formulaire 
    public static function reponseFormulaire(){
       $contenu= $_SESSION['contenu'];
       $contenuForm=$_SESSION['idContenuFormluaire'];
       $sql="INSERT INTO reponse_question VALUES(ID_REPONSE,$contenuForm,'$contenu');";
  
       $res = PDOLegalTech::$monPdo->exec($sql);	

        //Req SQL qui récupère l'id de la question et la valeur coché ou écrite pour la stocké dans la table reponse question
        //ainsi que l'id de utilisateur avec la session
    }

    //permet de stcoké les id pour pouvoir crée ensuite un dahsboard U,A
    public static function contenueFormulaire(){
        $idUser=$_SESSION['idUser'];
        $idFormulaire=$_SESSION['idForm'];
        $sql="INSERT INTO contenu_formulaire values(ID_CONTENU_FORMULAIRE,$idUser,$idFormulaire,1);";
        $res = PDOLegalTech::$monPdo->exec($sql);
    }

    public static function idcontenueFormulaire(){
        $sql="SELECT * FROM contenu_formulaire WHERE ID_CONTENU_FORMULAIRE=(SELECT MAX(ID_CONTENU_FORMULAIRE) FROM contenu_formulaire);";
        $res = PDOLegalTech::$monPdo->query($sql);
         $ligne1 = $res->fetchAll();
         return $ligne1;
    }
    public static function dashboardUEnTraitement(){
        // permet de voir les service a qui l'utilisateur et inscrit et voir son avancement dans un futur tableau?
        $utilisateur=$_SESSION['idUser'];
        $sql = "SELECT LIBELLE,LIBELLEE,ID_CONTENU_FORMULAIRE FROM etat e, formulaire f, contenu_formulaire cf WHERE e.ID_ETAT=cf.ID_ETAT AND cf.ID_FORMULAIRE=f.ID_FORMULAIRE AND ID_UTILISATEUR=$utilisateur AND e.ID_ETAT=1;";
        $res = PDOLegalTech::$monPdo->query($sql);
        $ligne1 = $res->fetchAll();
        return $ligne1;
    }
    public static function dashboardUAutre(){
        // permet de voir les service a qui l'utilisateur et inscrit et voir son avancement dans un futur tableau?
        $utilisateur=$_SESSION['idUser'];
        $sql = "SELECT LIBELLE,LIBELLEE,ID_CONTENU_FORMULAIRE FROM etat e, formulaire f, contenu_formulaire cf WHERE e.ID_ETAT=cf.ID_ETAT AND cf.ID_FORMULAIRE=f.ID_FORMULAIRE AND ID_UTILISATEUR=$utilisateur AND e.ID_ETAT <> 1;";
        $res = PDOLegalTech::$monPdo->query($sql);
        $autre = $res->fetchAll();
        return $autre;
    }


    public static function dashboardA(){
        //req qui permet de pouvoir faire un tableau informatif sur les nouvelle demande des client ainsi que les client fini 
        //Crée un tableau avec tous les clients avec l'état en cours avec le nom du formualaire demandé 
        $sql="SELECT *  FROM etat e, formulaire f, contenu_formulaire cf, utilisateur u WHERE  u.ID_UTILISATEUR= cf.ID_UTILISATEUR  AND e.ID_ETAT=cf.ID_ETAT AND cf.ID_FORMULAIRE=f.ID_FORMULAIRE; ";
        $res = PDOLegalTech::$monPdo->query($sql);
        $ligne1 = $res->fetchAll();
        return $ligne1; 
    } 




    public static function dashboardAEnTraitement(){
        //req qui permet de pouvoir faire un tableau informatif sur les nouvelle demande des client ainsi que les client fini 
        //Crée un tableau avec tous les clients avec l'état en cours avec le nom du formualaire demandé 
        $sql="SELECT LIBELLE,LIBELLEE, NOM, PRENOM, ID_CONTENU_FORMULAIRE  FROM etat e, formulaire f, contenu_formulaire cf, utilisateur u WHERE  u.ID_UTILISATEUR= cf.ID_UTILISATEUR  AND e.ID_ETAT=cf.ID_ETAT AND cf.ID_FORMULAIRE=f.ID_FORMULAIRE AND e.ID_ETAT=1;";
        $res = PDOLegalTech::$monPdo->query($sql);
        $autre = $res->fetchAll();
        return $autre; 
    } 
    public static function dashboardAAutre(){ 
        $sql="SELECT LIBELLE,LIBELLEE, NOM, PRENOM, ID_CONTENU_FORMULAIRE  FROM etat e, formulaire f, contenu_formulaire cf, utilisateur u WHERE  u.ID_UTILISATEUR= cf.ID_UTILISATEUR  AND e.ID_ETAT=cf.ID_ETAT AND cf.ID_FORMULAIRE=f.ID_FORMULAIRE AND e.ID_ETAT!=1;";
        $res = PDOLegalTech::$monPdo->query($sql);
        $ligne2 = $res->fetchAll();
        return $ligne2; 
    } 


    
    public static function detailCommandeDashboardUtilisateur($idcontenu){
        //req qui permet d'affiché le detail de la commande effectuer par l'utilisateur de son service
        $iduser=$_SESSION['idUser'];
        $sql="SELECT * FROM reponse_question  WHERE  ID_CONTENU_FORMULAIRE=$idcontenu";
        $res = PDOLegalTech::$monPdo->query($sql);
        $ligne1 = $res->fetchAll();
        return $ligne1;
    }


  //fonction Validation dossier
  public static function ValidationDossier($idcontenu){ 
    
            $sql="UPDATE contenu_formulaire SET ID_ETAT = 2 WHERE ID_CONTENU_FORMULAIRE = $idcontenu";
            $res = PDOLegalTech::$monPdo->exec($sql);

  }
  //fonction refus dossier
  public static function RefusDossier($idcontenu){ 
    
    $sql="UPDATE contenu_formulaire SET ID_ETAT = 3 WHERE ID_CONTENU_FORMULAIRE = $idcontenu";
    $res = PDOLegalTech::$monPdo->exec($sql);

}

}
?>